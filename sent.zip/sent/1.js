
function append(text) {
    document.getElementById("equation").value += text
}

function clearEquation() {
    document.getElementById("equation").value = ""
    document.getElementById("result").value = ""
}

function backspace(text) {
    document.getElementById("equation").value = text.substring(0, text.length - 1)
}
function hasWhiteSpace(s) {
    return /\s/g.test(s);
  }

function startEvaluation(equation) {

    console.log(eval(equation))
   var brackets = []
    var operators = []
    var operands = []
    var operandString = ""


    for (var index = 0, operatorIndex = 0, bracketIndex = 0; index < equation.length; index++) {

        if (equation.charAt(index) == '+'
            || equation.charAt(index) == '-'
            || equation.charAt(index) == '*'
            || equation.charAt(index) == '/') {

            if (equation.charAt(index - 1) == ')' && equation.charAt(index + 1) == '(') {
                operators[operatorIndex++] = "*"
                brackets[bracketIndex++] = null
                brackets[bracketIndex++] = null
                operators[operatorIndex++] = equation.charAt(index)
                operandString += " 1 "
            }
            else {
                operators[operatorIndex++] = equation.charAt(index)
                brackets[bracketIndex++] = null

                operandString += " "
            }
        }
        else if (equation.charAt(index) == '(' || equation.charAt(index) == ')') {
            brackets[bracketIndex++] = equation.charAt(index)
            operators[operatorIndex++] = null
        }
        else {
            operandString += equation.charAt(index)
        }
    }

    operandsTemp = operandString.split(" ")

    for (var index = 0, indexOperand = 0; index < operators.length; index++) {
        if (brackets[index] == null) {
            operands[index] = Number(operandsTemp[indexOperand++])
        }
        else {
            operands[index] = null
        }
    }
    operands[operands.length] = Number(operandsTemp[indexOperand])



    console.log(brackets)
    console.log(operators)
    console.log(operands)


    var result = 0
    var finalResult = 0

    if (brackets.length > 0) {

        for (var index = 0; index < brackets.length; index++) {

            if (brackets[index] == ')') {
                var indexBracketEnd = index
                for (var indexBracket = indexBracketEnd; indexBracket >= 0; indexBracket--) {
                    if (brackets[indexBracket] == '(') {
                        var indexBracketStart = indexBracket
                        evaluate(indexBracketStart, indexBracketEnd, operators, operands)
                        brackets[indexBracketStart] = null
                        brackets[indexBracketEnd] = null
                        break
                    }
                }
                console.log(brackets)
            }
        }
    }



    finalResult = evaluate(0, operators.length, operators, operands)


    console.log(`FINAL RESULT = ${finalResult}`)

    document.getElementById('result').value = finalResult
}

function evaluate(indexStart, indexEnd, operators, operands) {

    for (var index = indexStart; index < indexEnd; index++) {

        var indexFirstOperand = index
        var indexNextOperand = index + 1
        var indexNextOperator = index

        if (operators[indexNextOperator] == null) {
            for (var indexNext = indexNextOperator + 1; indexNext < operators.length; indexNext++) {
                if (operators[indexNext] != null) {
                    indexNextOperator = indexNext
                    indexFirstOperand = indexNext
                    indexNextOperand = indexNext + 1
                    index = indexNext - 1
                    break
                }
            }
        }

        if (operands[indexNextOperand] == null) {
            for (var indexNext = indexNextOperand + 1; indexNext < operands.length; indexNext++) {
                if (operands[indexNext] != null) {
                    indexNextOperand = indexNext
                    index = indexNext - 1
                    break
                }
            }
        }

        if (operators[indexNextOperator] == '*') {
            result = operands[indexFirstOperand] * operands[indexNextOperand]

            operands[indexNextOperand] = result
            operands[indexFirstOperand] = null
            operators[indexNextOperator] = null
            finalResult = result
            result = 0

            console.log(operands)
            console.log(operators)
        }
        else if (operators[indexNextOperator] == '/') {
            result = operands[indexFirstOperand] / operands[indexNextOperand]

            operands[indexNextOperand] = result
            operands[indexFirstOperand] = null
            operators[indexNextOperator] = null
            finalResult = result
            result = 0

            console.log(operands)
            console.log(operators)
        }
    }

    for (var index = indexStart; index < indexEnd; index++) {

        var indexFirstOperand = index
        var indexNextOperand = index + 1
        var indexNextOperator = index

        if (operators[indexNextOperator] == null) {
            for (var indexNext = indexNextOperator + 1; indexNext < operators.length; indexNext++) {
                if (operators[indexNext] != null) {
                    indexNextOperator = indexNext
                    indexFirstOperand = indexNext
                    indexNextOperand = indexNext + 1
                    index = indexNext - 1
                    break
                }
            }
        }

        if (operands[indexNextOperand] == null) {
            for (var indexNext = indexNextOperand + 1; indexNext < operands.length; indexNext++) {
                if (operands[indexNext] != null) {
                    indexNextOperand = indexNext
                    index = indexNext - 1
                    break
                }
            }
        }

        if (operators[indexNextOperator] == '+') {
            result = operands[indexFirstOperand] + operands[indexNextOperand]

            operands[indexNextOperand] = result
            operands[indexFirstOperand] = null
            operators[indexNextOperator] = null
            finalResult = result
            result = 0

            console.log(operands)
            console.log(operators)
        }
        else if (operators[indexNextOperator] == '-') {
            result = operands[indexFirstOperand] - operands[indexNextOperand]

            operands[indexNextOperand] = result
            operands[indexFirstOperand] = null
            operators[indexNextOperator] = null
            finalResult = result
            result = 0

            console.log(operands)
            console.log(operators)
        }
    }

    return finalResult
}